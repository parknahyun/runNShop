# AI 활용 개발 공정 — 산출물 표준양식 (전 공정 40종)

**버전: 1.0 (초안)**
**관련 문서**: `AI활용_개발공정_가이드_v2.2` 6장(공정별 산출물 상세), `AI활용_개발공정_프롬프트_라이브러리_v2.0.md`(40종 전체 프롬프트 샘플 수록)
**목적**: 6장이 정의한 "입력자료·AI초안·휴먼결정포인트"에 더해, 각 산출물이 **구체적으로 어떤 항목(구조)에
어떤 내용을 담아야 하는가**를 정의한다. 6장과 중복하지 않도록, 여기서는 **필수 항목(표준양식)**만 다룬다.

---

## 0. 공통 원칙

- **AI 협업 전제**: 모든 산출물은 4.1절 실행 사이클(Asset Selection → AI Generation → Human Review
  → Artifact Finalization → Asset Management)로 만들어진다. 아래 "필수 항목"은 AI Generation
  단계에서 AI가 채워야 할 항목이며, Human Review는 5.1절 품질기준(완전성·일관성·추적성·실행가능성·
  정책준수)으로 판정한다.
- **표준양식의 두 단계**: ① 이 문서(가이드 6장 + 여기)가 정의하는 **최소 필수 항목**으로 우선
  작성해본다. ② O3(자산화) 자기완결성 검증에서 부족함이 드러나면(Task Spec 사례처럼) 그 산출물만
  **전용 표준양식**으로 별도 정교화한다 — 처음부터 40종 모두 전용 표준양식을 만들 필요는 없다.
- **출처 추적**: 모든 산출물은 `source_*` 필드(또는 "근거 자료 출처 매핑" 섹션)로 입력 자료를
  역추적할 수 있어야 한다(추적성 기준).
- **Gap 표기 원칙**: 원본 자산에 근거가 없는 항목은 추정으로 채우지 않고 "확인 필요"로 명시한다
  (00-proposal 6종 작성에서 이미 실증된 원칙).
- **파일 형식 원칙**: 모든 산출물은 기본적으로 **Markdown(.md)** 문서 하나로 작성한다. ERD·상태머신·
  시퀀스·의존성맵처럼 구조화된 서브 표기가 필요한 항목은 표준 표기법(**DBML/PlantUML/
  OpenAPI YAML**)을 .md 안에 **코드블록으로 내장**하는 것을 기본으로 하고, 도구 연동(Swagger 검증,
  dbdiagram.io, CI 파이프라인 등)이 실제로 필요해지는 시점에만 그 블록을 별도 파일(.yaml/.dbml/.puml)로
  추출한다 — 처음부터 파일을 쪼개 관리 부담을 늘리지 않는다. 유일한 예외는 **"코드 구현"**으로,
  이건 산출물 자체가 실제 소스코드(언어별 확장자)와 Mock 데이터(.json)라 처음부터 별도 파일이다.
  아래 각 표의 "파일 형식(권장)" 열은 이 원칙을 산출물별로 구체화한 것이다.
- **다이어그램 표기법은 PlantUML로 통일**(Mermaid 미사용, 페페 확인 2026-07-28): 시퀀스·클래스설계가
  이미 PlantUML을 쓰고 있어, 상태머신·비즈니스프로세스(액티비티/스윔레인)·컴포넌트·상위유스케이스·
  의존성맵 등 나머지 다이어그램 유형도 전부 PlantUML로 맞춰 렌더러·문법을 하나로 통일한다. (트레이드오프:
  Mermaid는 GitHub 등에서 플러그인 없이 바로 렌더링되는 반면 PlantUML은 별도 렌더 서버/플러그인이
  필요하다 — 이 프로젝트는 일관성을 우선한다)

---

## 1. Proposal (Initiative 단위, 6종)

이미 `docs_ai/00-proposal/`에 6종 전체가 실제 작성됨 — 아래는 그 실제 구조를 표준양식으로 요약한 것.

| 산출물 | Scope | 필수 항목(표준양식) | 파일 형식(권장) | 실제 사례 |
|---|---|---|---|---|
| 문제정의서 | Initiative | **BPIO 4단**(Background·Problem·Impact·Opportunity, 각 2~5문장) + 근거출처매핑 + Human Review 목록 + 5.1 자가평가 | `.md` | `01-문제정의서.md` |
| 목표·KPI | Initiative | Objective(정성 목표) N개 + 각 Objective의 KR(정량 목표수치) 목록, KR마다 [목표수치/출처/비고] | `.md` (표) | `02-목표KPI.md` |
| 이해관계자맵 | Initiative | 이해관계자 표[이름·역할·관심사/영향력·근거] + 방법론 역할(PM/TL/DE/QA/AI CoE/AM/Dev) 매핑표 | `.md` (표) | `03-이해관계자맵.md` |
| 범위(Scope) | Initiative | In-Scope(확정/검토중)·Out-of-Scope 표 + **제외 항목 리스크 수용 여부**(휴먼결정포인트 직결) | `.md` (표) | `04-범위(Scope).md` |
| 대안비교 | Initiative | 대안 단위별 [후보 목록 + 채택여부 + 채택이유] 표 (대안이 여러 축이면 축마다 별도 표) | `.md` (표) | `05-대안비교.md` |
| 리스크·가정 | Initiative | 리스크 표[리스크·발생여부·영향도·출처·대응] + 가정 표[가정·검증상태·근거] | `.md` (표) | `06-리스크가정.md` |

---

## 2. Spec (Project/Bolt 단위, 6종)

| 산출물 | Scope | 필수 항목(표준양식) | 파일 형식(권장) |
|---|---|---|---|
| 용어집 | Project(현행화: Bolt) | 용어-정의 표[용어·정의·동의어·충돌여부], 신규 용어 발견 시 별도 표기, 버전 이력 | `.md` (표) |
| 제약사항 | Project | 제약 표[제약ID·카테고리(법무/보안/기술/벤더계약)·내용·적용범위·예외승인여부] | `.md` (표) |
| 비기능요구(NFR) | Project+Domain | 품질특성별 표[특성(성능/가용성/보안 등)·기준치·측정방법·근거]. 안정화 단계에서 실측 기준으로 현행화 | `.md` (표) |
| 기능요구(EARS) | Bolt | 요구사항ID(`REQ-{DOM}-{SEQ}`) + EARS 5패턴(Ubiquitous/Event-driven/State-driven/Optional/Unwanted) 중 해당 패턴으로 "WHEN [트리거], THE [시스템] SHALL [동작]" 문장 + 출처(정책서 챕터·화면 영역) + 우선순위(P1/P2/P3) | `.md` (요구사항ID 표) |
| 수용기준(GWT) | Bolt | 시나리오ID(`AC-{DOM}-{SEQ}`) + Given/When/Then + 카테고리(정상/경계값/예외) + 대응 EARS ID(요구사항 100% 커버 확인) | `.md` (표) — 테스트 자동화 연동 시 `.feature`(Gherkin) 추출 |
| 인터페이스 명세 | Bolt | OpenAPI 3.0 형식: endpoint(method/path/auth/role), request/response 필드표, 공통 응답구조, error_catalog, cross_field_rules | `.md` (yaml 블록 내장) — Swagger 등 도구 연동 시 `.yaml`/`.json` 추출 |

*프롬프트 샘플: Spec 전 6종 — `AI활용_개발공정_프롬프트_라이브러리_v2.0.md` 7~12절*

---

## 3. Design (Project/Domain/Bolt 단위, 11종)

| 산출물 | Scope | 필수 항목(표준양식) | 파일 형식(권장) |
|---|---|---|---|
| 컴포넌트 | Project | 모듈/서비스 목록 + 책임 정의 + 배포·책임 경계 + 의존관계 다이어그램 | `.md` (plantuml component 블록) |
| 상위 유스케이스 | Domain | 액터 정의 + 액터-유스케이스 관계도(다이어그램) + 권한 범위 | `.md` (plantuml usecase 블록) |
| 도메인·ERD | Domain(현행화: Bolt) | DBML 형식: 테이블별 컬럼(타입/nullable/default) + PK/FK + 인덱스 + **불변식(invariants)** + 상태전이 필드 있으면 명시 + soft delete 정책 + 감사컬럼 + 유스케이스/화면 대응 주석 | `.md` (dbml 블록 내장) — dbdiagram.io 연동 시 `.dbml` 추출 |
| 상태머신 | Domain(현행화: Bolt) | 상태 목록 + 허용 전이표 + **forbidden_transitions**(금지 전이 + 사유) + 전이 트리거 조건 | `.md` (plantuml state 블록) |
| 비즈니스 프로세스 | Domain | 액티비티 다이어그램(스윔레인, PlantUML) + 시작/종료조건 + 예외흐름(E1, E2...) | `.md` (plantuml activity/스윔레인 블록) |
| 이벤트 플로우 | Domain 간 | 이벤트 카탈로그[이벤트명·발행도메인·구독도메인·스키마·동기/비동기] | `.md` (표) |
| 세부 유스케이스 | Bolt | 버튼/메뉴 단위 액터 행위 분해 + 상위 유스케이스와의 연결 | `.md` (표) |
| 시퀀스 | Bolt | PlantUML 다이어그램 + **트랜잭션 경계**(rect 블록) + **이벤트 발행 타이밍**(BEFORE/AFTER COMMIT) + 실패 분기(alt/opt) + wrong_patterns | `.md` (plantuml 블록 내장) — 별도 렌더링 필요 시 `.puml` 추출 |
| 화면 레이아웃(확정) | Bolt | 와이어프레임 + 컴포넌트-API 매핑표 + 프론트 검증규칙 + 상태(state) 소스·refresh trigger + loading/optimistic 패턴 | `.md` (+ 와이어프레임은 `.png`/Figma 링크) |
| ADR | Domain/Bolt | 제목 + 상태(제안/승인/폐기) + Context(배경) + Decision(결정) + Alternatives(대안+트레이드오프) + Consequences(결과) | `.md` (ADR 1건=1파일 권장, `adr/NNNN-제목.md`) |
| 클래스 설계 | Bolt(현행화) | 클래스 다이어그램(속성/메서드/관계) + 책임 분배 + 상속/합성 구조 | `.md` (plantuml classDiagram 블록) |

*프롬프트 샘플: Design 전 11종 — 프롬프트 라이브러리 v2.0 13~23절*

---

## 4. Tasks (Initiative/Project/Domain/Bolt 단위, 6종)

| 산출물 | Scope | 필수 항목(표준양식) | 파일 형식(권장) |
|---|---|---|---|
| RACI | Initiative | 산출물×역할 매트릭스(R/A/C/I) + 방법론 역할↔실제 담당자 매핑(03-이해관계자맵 참조) | `.md` (표, 항목 방대 시 `.csv` 병행) |
| DoD 템플릿 | Project | 카테고리별 체크항목 풀(코드품질/테스트/보안/문서화 등) | `.md` (체크리스트) |
| 리스크 대응계획 | Initiative+Bolt | 트리거조건 → 대응액션 매핑 + 우선순위 + 담당자 (06-리스크가정의 리스크를 이어받음) | `.md` (표) |
| 의존성 맵 | Domain+Bolt | 작업 간 선후관계(DAG) + 크리티컬 패스 표시 | `.md` (plantuml 블록, 화살표로 DAG 표현) |
| WBS(하위)·산정 | Bolt | Epic > Story > Task 분해 + Task별 예상시간(최대 반나절) + 선행 Task ID + DoD 체크 항목 + 담당(FE/BE) | `.md` (표) — 이슈트래커 연동 시 `.csv` export |
| DoD 체크리스트(Bolt 적용본) | Bolt | DoD 템플릿에서 해당 Bolt에 맞는 카테고리만 선택 + 체크 결과 | `.md` (체크리스트) |

*프롬프트 샘플: Tasks 전 6종 — 프롬프트 라이브러리 v2.0 24~29절*

---

## 5. Code (Bolt 단위, 5종)

| 산출물 | Scope | 필수 항목(표준양식) | 파일 형식(권장) |
|---|---|---|---|
| 코드 구현 | Bolt | 레이어별 파일 목록(Controller/Service/Repository/DTO) + 네이밍 규칙 준수 + 코딩 컨벤션 준수 여부 | **실제 소스코드**(언어별 확장자, 예: `.kt`/`.ts`/`.tsx`) + Mock 데이터 `.json` — 유일하게 .md가 아닌 산출물 |
| 자동 검증(활동) | Bolt | 컴파일/Lint/SAST 결과 리포트 + 실패 시 재시도 이력 | `.md` (결과 요약) — 원본 리포트는 도구별 `.xml`(JUnit)/`.json`(SARIF) |
| 단위 테스트 실행·결과 | Bolt | 테스트케이스(GWT 경계값 기반) + 커버리지 수치 + Pass/Fail 기록 | 테스트 코드(언어별 확장자) + 결과 요약 `.md` |
| 클래스 설계(현행화) | Bolt | Design 산출물과 동일 포맷 — **변경사항만 diff로 기록**(구현 중 설계 차이 발견 시) | `.md` (plantuml 블록, diff 서술) |
| 도메인·ERD/상태머신(현행화) | Domain | Design 산출물과 동일 포맷 — 변경사항만 diff로 기록 | `.md` (dbml/plantuml 블록, diff 서술) |

*프롬프트 샘플: Code 전 3종(신규분) — 프롬프트 라이브러리 v2.0 30~32절*

---

## 6. 통합 테스트 (Project/Domain/Bolt 단위, 10종)

| 산출물 | Scope | 필수 항목(표준양식) | 파일 형식(권장) |
|---|---|---|---|
| 통합테스트 계획서 | Project | 시나리오 목록 + 범위/우선순위 + 의존성맵·ADR 참조 | `.md` |
| 수용기준(GWT) 실행(활동) | Bolt | Spec 단계 GWT를 그대로 실행 — Pass/Fail 기록만 | `.md` (표) — 자동화 시 `.feature` 실행 결과 |
| 이벤트플로우(현행화) | Domain 간 | Design 산출물과 동일 포맷 + "통합 중 발견사항" 섹션 추가 | `.md` (표) |
| 의존성맵(현행화) | Domain+Bolt | Tasks 산출물과 동일 포맷 + "통합 중 발견사항" 섹션 추가 | `.md` (plantuml 블록) |
| 리스크·가정(현행화) | Initiative | Proposal 산출물과 동일 포맷 + "통합 중 발견사항" 섹션 추가 | `.md` (표) |
| 통합테스트 결과보고서 | Project | 시나리오별 결과 + 발견된 결함(5.2 등급별: Critical/Major/Minor/Trivial) + 재현 조건 | `.md` |
| E2E 시나리오 | Project | 실사용자 관점 흐름(통합테스트 결과 기반) | `.md` — 자동화 시 `.spec.ts`(Playwright/Cypress) 병행 |
| NFR(현행화) | Project | Spec 산출물과 동일 포맷 — 실측치로 기준 보정 | `.md` (표) |
| DoD 체크리스트(최종) | Bolt | 전체 항목 최종 확인 결과 | `.md` (체크리스트) |
| Go/No-Go 판단근거 | Project | 5.2 Go/No-Go 판단 매트릭스 적용 결과 + Critical/Major 건수 + 최종 판정 | `.md` |

*프롬프트 샘플: 신규 4종(계획서·결과보고서·E2E·Go-No-Go) — 프롬프트 라이브러리 v2.0 33~36절*

---

## 7. 안정화 (Project/Initiative 단위, 9종)

| 산출물 | Scope | 필수 항목(표준양식) | 파일 형식(권장) |
|---|---|---|---|
| 운영매뉴얼/Runbook | Project | 장애대응 절차 + 에스컬레이션 경로 + 담당자 연락처 | `.md` |
| Go-Live 승인기록 | Project | 승인자 + 승인일시 + Go/No-Go 판단근거 문서 링크 | `.md` (짧은 표) |
| 목표·KPI(베이스라인) | Initiative | 오픈 시점 실측값 기록 시작 | `.md` (표) |
| 장애/이슈 로그 | Project | 발생일시 + 등급 + 원인 + 조치 + 재발방지책 (지속 누적) | `.md` (표) — 누적량 많으면 `.csv`/이슈트래커 연동 |
| 리스크 대응계획(현행화) | Initiative+Bolt | Tasks 산출물과 동일 포맷 — 실제 발생 이슈로 갱신 | `.md` (표) |
| NFR(현행화) | Project | 운영 실측 기준으로 재조정 | `.md` (표) |
| 용어집(현행화) | Project | 운영 중 발생한 신조어 반영, 최종 확정 | `.md` (표) |
| 목표·KPI(최종) | Initiative | 목표 대비 실적 비교 | `.md` (표) |
| 안정화 결과보고서 | Project | 전체 과정 종합 + KPI 달성 평가 + **자산화(다음 프로젝트 재사용) 권고사항** | `.md` |

*프롬프트 샘플: 신규 4종(운영매뉴얼·Go-Live승인·장애로그·안정화결과보고서) — 프롬프트 라이브러리 v2.0 37~40절*

---

## 부록: 산출물 개수 검산

Proposal 6 + Spec 6 + Design 11 + Tasks 6 + Code 5(코드구현·자동검증·단위테스트 신규 3종, 클래스설계·
도메인ERD 현행화 2종은 Design과 동일 산출물이라 고유 개수에서 제외) + 통합테스트 4(신규: 계획서·
결과보고서·E2E·Go-No-Go, 나머지 6개는 현행화/활동) + 안정화 4(신규: 운영매뉴얼·Go-Live승인·
장애로그·안정화결과보고서, 나머지 5개는 현행화) = **고유 산출물 40종**(O3 KR3-2가 가리키는 숫자와 일치).

## 변경 이력

v1.0 (2026-07-28): 초판 작성 — 가이드 6장 40종 전체에 대해 필수 항목(표준양식) 정의. Proposal
6종은 `docs_ai/00-proposal/` 실제 사례를 역반영. 나머지 34종은 가이드 6장 설명·업계 표준 구조
(EARS/GWT/ADR/RACI 등 이미 확립된 형식)를 근거로 신규 정의 — 실제 자기완결성 검증은 아직
미실시(O3 KR3-2에서 순차 진행 예정).

v1.0 개정 (2026-07-28): 40종 전체 표에 **"파일 형식(권장)"** 열 추가. 기본 원칙은 "모든 산출물은
.md, 구조화 서브 표기(ERD/상태머신/시퀀스/의존성맵/인터페이스명세)는 DBML/PlantUML/Mermaid/
OpenAPI YAML을 .md 안에 코드블록으로 내장" — `docs_method/산출물-샘플/`에서 실제로 이 방식을 써본
결과(02-Design.md의 dbml·mermaid·plantuml 블록, 01-Spec.md의 yaml 블록)를 역반영해 확정했다.
유일한 예외는 "코드 구현"(실제 소스코드+Mock JSON)이며, 이 예외도 `04-Code.md` 실제 작성
사례에서 그대로 확인됨.

v1.0 개정 2 (2026-07-28): 다이어그램 표기법을 **Mermaid → PlantUML로 통일**(페페 확인). 시퀀스·
클래스설계가 이미 PlantUML을 쓰고 있었는데 컴포넌트·상위유스케이스·상태머신·비즈니스프로세스·
의존성맵(현행화 포함)이 Mermaid로 남아 있어 다이어그램 도구가 둘로 갈라져 있던 걸 정리했다.
공통 원칙에 통일 원칙 + 트레이드오프(Mermaid는 GitHub 등에서 무플러그인 렌더링, PlantUML은
별도 렌더러 필요 — 일관성 우선으로 PlantUML 선택)를 명시했다. `docs_method/산출물-샘플/`의 기존
Mermaid 블록(02-Design.md 컴포넌트·비즈니스프로세스, 03-Tasks.md 의존성맵, 05-통합테스트.md
의존성맵현행화)은 아직 미반영 — 별도 작업으로 남김.
